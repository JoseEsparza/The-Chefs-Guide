<!DOCTYPE html>
<html lang="en" ng-app='TCG'>
	<head>
		<meta charset="utf-8">
		<title>The Chef's Guide</title>
		<link rel="stylesheet" type="text/css" href="Style/bootstrap-3.3.7-dist/css/bootstrap.css">
		<link rel="stylesheet" type="text/css" href="Style/TCG.css">
		<link rel="stylesheet" type="text/css" href="Style/font-awesome-4.7.0/css/font-awesome.min.css">
	</head>
	<body ng-controller="main">

		<!-- Menú -->
		<header>
			<nav class="navbar navbar-default navbar-fixed-top m_menu">
				<div class="container-fluid">
					<div class="navbar-header">
						<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#Main_menu">
							<span class="sr-only">Menu</span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>
						<a href="#" class="navbar-brand">The Chef's Guide<img src=""></a>
					</div>
					<div class="collapse navbar-collapse" id="Main_menu">
						<ul class="nav navbar-nav navbar-right m_menu2">
							<li class=""><a href="">Recetas</a></li>
							<li class=""><a href="">Consejos</a></li>
							<li class=""><a href="">Mi Menu</a></li>
							<li class="dropdown">
								<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button">Perfil <span class="caret"></span></a>
								<ul class="dropdown-menu">
									<li><a href="">Entrar</a></li>
									<li><a href="">Registrarme</a></li>
								</ul>
							</li>
						</ul>
					</div>
				</div>
			</nav>
		</header>


		<script src="http://code.jquery.com/jquery-latest.js"></script>
		<script src="JS/jquery.easing.min.js"></script>
		<script src="JS/angular.min.js"></script>
		<script src="JS/ui-bootstrap-tpls-2.1.2.min.js"></script>
		<script src="Style/bootstrap-3.3.7-dist/js/bootstrap.min.js"></script>
		<script>

			function getParameterByName(name, url) {
	    		if (!url) url = window.location.href;
	    		name = name.replace(/[\[\]]/g, "\\$&");
			    var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
			        results = regex.exec(url);
			    if (!results) return null;
			    if (!results[2]) return '';
			    return decodeURIComponent(results[2].replace(/\+/g, " "));
			}

			var idreceta = getParameterByName('id');
			console.log(idreceta);

			var app = angular.module('TCG', [])


			app.controller('main', ['$scope', '$http', '$filter', '$location', function($scope, $http, $filter, $location){


				$scope.o_recetas = Array();

				$scope.pasos = Array();

				$scope.fotos = Array();


				$scope.id_url =

				$http({
				  method: 'GET',
				  url: 'http://localhost/api/api.php/recetas'
				}).then(function successCallback(response) {
				    // this callback will be called asynchronously
				    // when the response is available

				    $scope.o_recetas = response.data
				    console.log($scope.o_recetas);

				    }, function errorCallback(response) {
				    // called asynchronously if an error occurs
				    // or server returns response with an error status.
				    console.log('Hubo un error!!!! NOOOOOOOOOOO')
				});

				$http({
				  method: 'GET',
				  url: 'http://localhost/api/api.php/pasos_receta'
				}).then(function successCallback(response) {
				    // this callback will be called asynchronously
				    // when the response is available

				    $scope.pasos = response.data
				    console.log($scope.pasos);

				    }, function errorCallback(response) {
				    // called asynchronously if an error occurs
				    // or server returns response with an error status.
				    console.log('Hubo un error!!!! NOOOOOOOOOOO')
				});

				$http({
				  method: 'GET',
				  url: 'http://localhost/api/api.php/fotos_recetas'
				}).then(function successCallback(response) {
				    // this callback will be called asynchronously
				    // when the response is available

				    $scope.fotos = response.data
				    console.log($scope.fotos);

				    }, function errorCallback(response) {
				    // called asynchronously if an error occurs
				    // or server returns response with an error status.
				    console.log('Hubo un error!!!! NOOOOOOOOOOO')
				});





			}])


		</script>

	</body>
</html>