<!DOCTYPE html>
<html lang="en" ng-app='TCG'>
	<head>
		<meta charset="utf-8">
		<title>The Chef's Guide</title>
		<link rel="stylesheet" type="text/css" href="Style/bootstrap-3.3.7-dist/css/bootstrap.css">
		<link rel="stylesheet" type="text/css" href="Style/TCG.css">
		<link rel="stylesheet" type="text/css" href="Style/font-awesome-4.7.0/css/font-awesome.min.css">
	</head>
	<body ng-controller="main">

		<!-- Menú -->
		<header>
			<nav class="navbar navbar-default navbar-fixed-top m_menu">
				<div class="container-fluid">
					<div class="navbar-header">
						<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#Main_menu">
							<span class="sr-only">Menu</span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>
						<a href="#" class="navbar-brand">The Chef's Guide<img src=""></a>
					</div>
					<div class="collapse navbar-collapse" id="Main_menu">
						<ul class="nav navbar-nav navbar-right m_menu2">
							<li class=""><a href="">Recetas</a></li>
							<li class=""><a href="">Consejos</a></li>
							<li class=""><a href="">Mi Menu</a></li>
							<li class="dropdown">
								<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button">Perfil <span class="caret"></span></a>
								<ul class="dropdown-menu">
									<li><a href="">Entrar</a></li>
									<li><a href="">Registrarme</a></li>
								</ul>
							</li>
						</ul>
					</div>
				</div>
			</nav>
		</header>

		<!-- Filtros -->
		<div class="container" id="Filtros">
			<div class="container-fluid">
				<div class="dropdown col-xs-6 col-md-2 co_min">
					<button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">Costo Mínimo
					<span class="caret"></span></button>
					<ul class="dropdown-menu">
						<li><a href="#">$100</a></li>
					    <li><a href="#">$200</a></li>
					    <li><a href="#">$300</a></li>
					</ul>
				</div>

				<div class="dropdown col-xs-6 col-md-2 co_max">
					<button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">Costo Máximo
					<span class="caret"></span></button>
					<ul class="dropdown-menu">
						<li><a href="#">$100</a></li>
					    <li><a href="#">$200</a></li>
					    <li><a href="#">$300</a></li>
					</ul>
				</div>

				<div class="dropdown col-xs-12 col-md-4 col-md-offset-4 ingredientes">
					<button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">Ingredientes
					<span class="caret"></span></button>
					<ul class="dropdown-menu">
						<li><a href="#">$100</a></li>
					    <li><a href="#">$200</a></li>
					    <li><a href="#">$300</a></li>
					</ul>
				</div>
			</div>
		</div>

		<!-- Recetas más recientes -->
		<div class="container" id="Cartas_recetas">
			<div class=" col-xs-10 col-md-4 carta_receta" ng-repeat="(key, nombre) in filtroItems">
				<img ng-src="http://localhost/TCG/Style/Assets/{{nombre.foto}}" alt="{{nombre.nombre_receta}}" class="img-responsive">
				<div class="nombre_receta">
					<a href="receta.php?id={{nombre.idrecetas}}" ng-click=""><span>{{nombre.nombre_receta}}</span></a><a href="" class="favorito"><i class="fa fa-heart-o" aria-hidden="true"></i></a>
				</div>
			</div>
		</div>

		<div class="container">
			<ul uib-pagination total-items="totalItems" items-per-page="12" ng-model="currentPage"></ul>
		</div>

		<!-- Footer -->
		<!-- <footer class="footer">
			<div class="container">
				<div class="text-center">
					<small>Copyright © Your Website 2017</small>
				</div>
			</div>
		</footer> -->


		<script src="http://code.jquery.com/jquery-latest.js"></script>
		<script src="JS/jquery.easing.min.js"></script>
		<script src="JS/angular.min.js"></script>
		<script src="JS/ui-bootstrap-tpls-2.1.2.min.js"></script>
		<script src="Style/bootstrap-3.3.7-dist/js/bootstrap.min.js"></script>

		<script>
			var app = angular.module('TCG', [])

			app.controller('main', ['$scope', '$http', '$filter', function($scope, $http, $filter){

				$scope.recetas = Array();
				$scope.o_recetas = Array();

				$http({
				  method: 'GET',
				  url: 'http://thechefsguides.org/thechefsguides.org/api.php/recetas'
				}).then(function successCallback(response) {
				    // this callback will be called asynchronously
				    // when the response is available

				    $scope.o_recetas = response.data;
				    $scope.inicializar();

				    }, function errorCallback(response) {
				    // called asynchronously if an error occurs
				    // or server returns response with an error status.
				    console.log('Hubo un error!!!! NOOOOOOOOOOO')
				});

				$scope.filtroItems = [];
				$scope.currentPage = 1;
				$scope.numPerPage = 5 ;
				$scope.totalItems = $scope.o_recetas.length;
				$scope.inicializar = function(){
					$scope.hacerPagineo($scope.o_recetas);
				}
				$scope.hacerPagineo = function(arreglo){
					var principio = (($scope.currentPage - 1) * $scope.numPerPage);
					var fin = principio + $scope.numPerPage;
					console.log(arreglo);
					$scope.filtroItems = arreglo.splice(principio, fin)
					console.log($scope.filtroItems);
				}

				console.log($scope.o_recetas);
				console.log($scope.filtroItems);

				// $scope.buscar = function(busqueda){
				// 	var buscados = $filter('$filter', $scope.o_recetas, function(receta){
				// 		return (receta.nombre_receta.toLowerCase().indexOf(busqueda.toLowerCase())>=1);
				// 	});
				// 	$scope.receta.totalItems = buscados.length;
				// 	$scope.hacerPagineo(buscados);

				// }

			}])
		</script>
	</body>
</html>